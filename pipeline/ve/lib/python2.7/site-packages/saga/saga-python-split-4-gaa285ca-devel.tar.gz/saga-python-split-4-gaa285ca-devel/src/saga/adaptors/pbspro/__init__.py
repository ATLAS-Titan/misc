__author__    = "Mark Santcroos"
__copyright__ = "Copyright 2015, The SAGA Project"
__license__   = "MIT"
