__author__    = "Mark Santcroos"
__copyright__ = "Copyright 2015, The RADICAL Project"
__license__   = "MIT"
